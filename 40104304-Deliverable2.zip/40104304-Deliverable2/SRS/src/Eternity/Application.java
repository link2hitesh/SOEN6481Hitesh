package Eternity;


public class Application {

    public static double application(int p) {
        double ans,e;
        e=Irrational.eulern(3);
        ans=Scientific.Power(e,p);
        return ans;
    }
    static double Log(double p, double b)
    {
        double w, N, s, nan=0;
        s = 1.0;

    
        if (p <= 1.0 || b <= 1.0)
        {
            if (p <= 0.0 || b <= 0.0 )
                return nan ;
            if (p < 1.0)
            {
                p = 1.0 / p;
                s *= -1.0;
            }
            if (b < 1.0)
            {
                s *= -1.0;
                b = 1.0 / b;
            }
            if (p == 1.0)
            {
                if (b != 1.0)
                {
                    return 0.0;
                }
                return 1.0;
            }
        }
    

            w = p;
        N = 0.0;

        while (w >= b)
        {
            w /= b;
            N++;
        }
        if (w == 1.0)
        {
            return (s * N);
        }
        return s * (N + (1.0 / Log(b, w)));
    }

    public static void main(String[] args) {
        System.out.println(Application.Log(27,2.716));
    }


}