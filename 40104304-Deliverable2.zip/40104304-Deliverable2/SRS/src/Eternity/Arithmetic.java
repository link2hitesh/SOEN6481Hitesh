package Eternity;

public class Arithmetic {


    public static double add(double num1, double num2){

        double sum;
        sum= num1+num2;
        return sum;

    }
    public static double sub(double num1, double num2){

        double sub;
        sub= num1-num2;
        return sub;

    }
    public static double multiply(double num1, double num2){

        double ans;
        ans= num1*num2;
        return ans;

    }

    public static double div(double num1, double num2){

        double ans;
        ans= num1/num2;
        return ans;

    }

}

