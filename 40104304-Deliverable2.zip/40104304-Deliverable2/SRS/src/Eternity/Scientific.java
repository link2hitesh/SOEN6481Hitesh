package Eternity;

public class Scientific {

    public static float facto(int n) {

        int i,fact = 1;

        for ( i = 1; i <=n; i++) {
            fact = fact * i;

        }
        return fact;

    }

    public static double Power(double n, int pow) {
        double ans=1;

        if(n==0)
        {
            System.out.println("ERROR");
        }
        if(pow==0)
        {
          ans=1;
        }
        if(pow<0)
        {
            pow=pow+(-2*pow);
            for (int i=1; i<=pow; i++)
            {
                ans= ans*n;
            }
            ans=1/ans;

        }
        else {
            for (int i = 1; i <= pow; i++) {
                ans = ans * n;

            }
        }

       return ans;
    }
        public static double sqrt(double number) {
        double t;

        double squareRoot = number / 2;

        do {
            t = squareRoot;
            squareRoot = (t + (number / t)) / 2;
        } while ((t - squareRoot) != 0);

        return squareRoot;
    }

}