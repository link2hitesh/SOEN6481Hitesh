package Eternity;

public class Irrational {

    public static double eulerno() {

        double e = 2.71828;
        return e;
    }

    public static double eulercal(int n) {

        double e = 0;
        int temp = (int)(e*100.0);
        double shortDouble = ((double)temp)/100.0;
        for (int i = 1; i <= n; i++) {
            e = e + (1 / Scientific.facto(n));
        }

        return e;
    }

    public static double eulern(int n)
    {
        double e=2.71828182845904;
        double multi=Scientific.Power(10,n);

        int temp = (int)(e*multi);
        double shortDouble = ((double)temp)/multi;
       return shortDouble;
    }



}