package Eternity;
import java.util.Scanner;
public class Calculator {

   public static void main(String ar[]) {
       Queue q = new Queue(5);
       Scanner sc = new Scanner(System.in);

       System.out.println("WELCOME TO ETERNITY: NUMBERS\n INSTRUCTIONS:");


       System.out.println("YOU HAVE THE FOLLOWING OPTIONS AVAILABLE:");
       System.out.println("1.ADDITION(+)\n 2.SUBTRACTION(-)\n 3.MULTIPLICATION(*)\n 4.DIVIDE(/)\n 5.EXPONENTIAL(^)\n 6.FACTORIAL(!)\n 7.SQUAREROOT(s))");
       System.out.println("You also have these special operations :\n" +
               "1.(e) returns the value of e\n" +
               "2.(e'n) return value of e till n decimal places\n" +
               "3.(e*n) calculates the value of e till n iterations\n" +
               "4.(e^x) to calculate e raised to the power x\n" +
               "5. \"If you want to use Euler's number as one of the operands, then enter the code 0.0 while you input values\n" +
               "6 (ln) to calculate natural log of a number\n" +
               "7.(v) to view the result of your previous five calculations");


      int wish=1;
       while(wish==1)
       {

           String choice;
           System.out.println("Enter the Symbol for your operation[Symbol is mentioned in parenthesis with each operation");
           choice = sc.nextLine();
           double op1 = 0, op2 = 0, result;

           switch (choice) {

               case "+":
                   System.out.println("Enter operand 1");
                   op1 = sc.nextDouble();
                   if (op1 == 0.0)
                       op1 = Irrational.eulerno();
                   System.out.println("Enter operand 2");
                   op2 = sc.nextDouble();
                   if (op2 == 0.0)
                       op2 = Irrational.eulerno();
                   result = Arithmetic.add(op1, op2);
                   q.enqueue(result);
                   System.out.println(result);
                   break;

               case "-":
                   System.out.println("Enter operand 1");
                   op1 = sc.nextDouble();
                   if (op1 == 0.0)
                       op1 = Irrational.eulerno();
                   System.out.println("Enter operand 2");
                   op2 = sc.nextDouble();
                   if (op2 == 0.0)
                       op2 = Irrational.eulerno();
                   result = Arithmetic.sub(op1, op2);
                   q.enqueue(result);
                   System.out.println(result);
                   break;

               case "/":
                   System.out.println("Enter operand 1");
                   op1 = sc.nextDouble();
                   if (op1 == 0.0)
                       op1 = Irrational.eulerno();
                   System.out.println("Enter operand 2");
                   op2 = sc.nextDouble();
                   if (op2 == 0.0)
                       op2 = Irrational.eulerno();
                   result = Arithmetic.div(op1, op2);
                   q.enqueue(result);
                   System.out.println(result);
                   break;

               case "*":
                   System.out.println("Enter operand 1");
                   op1 = sc.nextDouble();
                   if (op1 == 0.0)
                       op1 = Irrational.eulerno();
                   System.out.println("Enter operand 2");
                   op2 = sc.nextDouble();
                   if (op2 == 0.0)
                       op2 = Irrational.eulerno();
                   result = Arithmetic.multiply(op1, op2);
                   q.enqueue(result);
                   System.out.println(result);
                   break;

               case "^":
                   int pow;
                   System.out.println("Enter the number");
                   op1 = sc.nextDouble();
                   if (op1 == 0.0)
                       op1 = Irrational.eulerno();
                   System.out.println("Enter the power");
                   pow = sc.nextInt();
                   if (pow == 0.0) {
                       System.out.println("invalid input");
                       break;
                   }
                   else{

                   result = Scientific.Power(op1, pow);
                   q.enqueue(result);
                   System.out.println(result);
                   break;}

               case "!":
                   int num;
                   System.out.println("Enter the number");
                   num = sc.nextInt();
                   result = Scientific.facto(num);
                   System.out.println(result);
                   q.enqueue(result);
                   break;

               case "sq":
                   double numb;
                   System.out.println("Enter the number");
                   numb = sc.nextDouble();
                   result = Scientific.sqrt(numb);
                   System.out.println(result);
                   q.enqueue(result);
                   break;

               case "e":
                   System.out.println(Irrational.eulerno());
                   q.enqueue(Irrational.eulerno());
                   break;

               case "e'n":
                   int n;
                   System.out.println("enter the number of decimal places");
                   n = sc.nextInt();
                   System.out.println(Irrational.eulern(n));
                   q.enqueue(Irrational.eulern(n));
                   break;

               case "e*n":
                   System.out.println("enter the number of iterations<11");
                   n = sc.nextInt();
                   System.out.println(Irrational.eulercal(n));
                   q.enqueue(Irrational.eulercal(n));
                   break;

               case "e^x":
                   System.out.println("enter the power");
                   int p = sc.nextInt();
                   System.out.println(Application.application(p));
                   q.enqueue(Application.application(p));
                   break;

               case "ln": double base=Irrational.eulerno();
                          System.out.println("Enter the power");
                          op1=sc.nextInt();

                          System.out.println(Application.Log(op1,base));
                          break;

               case "v": q.display();

               default: System.out.println("Invalid choice");
           }

        System.out.println("Do you wiah to continue 1=yes 0=no");
        wish=sc.nextInt();
        sc.nextLine();

       }

   }

}
