package Eternity;

import java.util.*;


public class Queue
{
    private double arr[];
    private int front;
    private int rear;
    private int capacity;
    private int count;


    Queue(int size)
    {
        arr = new double[size];
        capacity = size;
        front = 0;
        rear = -1;
        count = 0;
    }

    public void display()
    {
        for(int i=0; i<size(); i++ )
        {
            System.out.println(arr[i]);
        }

    }

    public void dequeue()
    {
        if (isEmpty())
        {
            System.exit(1);
        }

        front = (front + 1) % capacity;
        count--;
    }


    public void enqueue(double item)
    {

        if (isFull())
        {
           dequeue();
        }

        rear = (rear + 1) % capacity;
        arr[rear] = item;
        count++;
    }

       public double peek()
    {
        if (isEmpty())
        {

            System.exit(1);
        }
        return arr[front];
    }

    public int size()
    {
        return count;
    }


    public Boolean isEmpty()
    {
        return (size() == 0);
    }


    public Boolean isFull()
    {
        return (size() == capacity);
    }
}

